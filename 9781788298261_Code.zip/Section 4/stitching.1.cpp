#include "opencv2/opencv.hpp"
#include "tile.hpp"
using namespace cv;
int main(int argc, char* argv[])
{
    auto filenames = std::vector<char*>(argv + 1, argv + argc);          // get photo file names 
    auto images = std::vector<Mat>(filenames.size());                    // create a vector of cv::Mats of the same size
    std::transform(filenames.begin(), filenames.end(), images.begin(),   // load all photos
                   [](auto fname) { return imread(fname); });            
                                                                         
    imshow("Input Photos", tile(images)); waitKey(1);                    // show all input photos
    Mat pano;                                                            
    Ptr<Stitcher> stitcher = Stitcher::create(Stitcher::PANORAMA, true); // create stitcher
    if (Stitcher::OK != stitcher->stitch(images, pano))                  // stitch images
        return EXIT_FAILURE;                                             // return on failure
                                                                         
    namedWindow("Panorama", WINDOW_NORMAL);                              // make window scalable
    resizeWindow("Panorama", 1900, 1900 * pano.rows / pano.cols);        // resize window to screen size
    imshow("Panorama", pano); waitKey();                                 // show the panorama   
    //
    //// Apply Opportunity rover color correction https://goo.gl/GEj4sn 
    //imshow("Panorama", pano.mul(Scalar(1.05, 1.2, 1.8)));                // reweight channels (R:NIR, G:Green, B:UV) 
    imwrite("pano.jpg", pano);                                           // save result
    //waitKey();
}