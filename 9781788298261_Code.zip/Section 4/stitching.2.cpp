#include "opencv2/opencv.hpp"
#include "tile.hpp"
using namespace cv;
int main(int argc, char* argv[])
{
    auto filenames = std::vector<char*>(argv + 1, argv + argc);         // get photo file names 
    auto images = std::vector<Mat>(filenames.size());                   // create a vector of cv::Mats of the same size
    std::transform(filenames.begin(), filenames.end(), images.begin(),  // load all photos
                   [](auto fname) { return imread(fname); });
    imshow("Input Photos", tile(images)); waitKey(10);                   // show all input photos

    Mat pano;
    auto stitcher = Stitcher::create(Stitcher::PANORAMA);               // create stitcher
    auto stitch = [&](std::string const& postfix = "")                  // helper lambda funtion
    {                                                                   
        if (Stitcher::OK != stitcher->stitch(images, pano)) return;             // stitch images and return on failure
        waitKey();                                                      
        namedWindow( "Panorama" + postfix, WINDOW_NORMAL);                      // make window scalable
        resizeWindow("Panorama" + postfix, 1900, 1900 * pano.rows / pano.cols); // resize window to screen size
        imshow(      "Panorama" + postfix, pano); waitKey(10);                  // show the panorama   
    };
    stitcher->setWaveCorrection(false);                                         // disable "wave-correction"
    stitch(": SphericalWarper, no wave correction");                            // stitch() and display
    stitcher->setWaveCorrection(true);                                          // re-enable "wave-correction"
    stitch(": SphericalWarper");                                                // stitch() and display
    stitcher->setWarper(makePtr<PlaneWarper>());                                // change warper to planar warping
    stitch(": PlaneWarper");                                                    // stitch() and display
    waitKey();
}