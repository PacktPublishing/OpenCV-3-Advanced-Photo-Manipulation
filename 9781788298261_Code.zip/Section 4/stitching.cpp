#include "opencv2/opencv.hpp"
#include "tile.hpp"

int main(int argc, char* argv[])
{
    using namespace cv;
    auto filenames = std::vector<char*>(argv + 1, argv + argc);         // get photo file names 
    auto images = std::vector<Mat>(filenames.size());                   // create a vector of cv::Mats of the same size
    std::transform(filenames.begin(), filenames.end(), images.begin(),  // load all photos
                   [](auto fname) { return imread(fname); });

    imshow("Input Photos", tile(images)); waitKey(10);                   // show all input photos
    Mat pano;
    Ptr<Stitcher> stitcher = Stitcher::create(Stitcher::PANORAMA, true);
    auto stitch = [&](std::string const& postfix = "")
    {
        if (Stitcher::OK != stitcher->stitch(images, pano))
            return;
        waitKey();
        namedWindow("Panorama" + postfix, WINDOW_NORMAL);
        resizeWindow("Panorama" + postfix, 1900, 1900 * pano.rows / pano.cols);
        imshow("Panorama" + postfix, pano); waitKey(10);
    };
    stitch();
    stitcher->setWarper(makePtr<CylindricalWarper>());
    stitch(": CylindricalWarper");
    //stitcher->setWarper(makePtr<PaniniWarper>());
    //stitch(": PaniniWarper");

    //stitcher->setWarper(makePtr<PlaneWarper>());
    //stitch(": PlaneWarper");
    waitKey();
    //if (Stitcher::OK != stitcher->stitch(images, pano))
    //    return EXIT_FAILURE;

    //// Opportunity Color Correction https://goo.gl/GEj4sn
    ////pano = pano.mul(Scalar(1.05, 1.2, 1.8));  // reweight channels (R:NIR, G:Green, B:UV)
    //
    //namedWindow("Panorama", WINDOW_NORMAL);
    //resizeWindow("Panorama", 1900, 1900 * pano.rows/pano.cols);
    //imshow("Panorama", pano); waitKey();
}

