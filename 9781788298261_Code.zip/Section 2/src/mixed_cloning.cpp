#include <opencv2/opencv.hpp>
using namespace cv;
int main(int argc, char* argv[])
{   
    if (argc < 3) return EXIT_FAILURE;
    Mat src = imread(argv[1]);          // read source image
    Mat dst = imread(argv[2]);          // read destination image
    if (src.empty() || dst.empty())
        return EXIT_FAILURE;
    imshow("Source",      src); waitKey(); // and show them
    imshow("Destination", dst); waitKey();  

    Rect src_roi(66,149,703,125);
    Point dst_pos{ 480,256 };
    Mat res, mask(cv::Mat::zeros(src.size(), CV_8UC1));
    mask(src_roi).setTo(255);

    seamlessClone(src, dst, mask, dst_pos, res, NORMAL_CLONE);
    imshow("Normal Clone", res); waitKey();

    seamlessClone(src, dst, mask, dst_pos, res, MIXED_CLONE);
    imshow("Mixed Clone", res); waitKey();
}