#include <opencv2/opencv.hpp>
int main()
{   
    cv::Mat img = cv::imread("door.jpg"); // read source image
    imshow("Input", img); cv::waitKey();  // otherwise show it

    cv::Rect door_roi(308, 92,227,432),   // top-left: x0, y0; width x height
             lwall_roi(53, 85,227,432),     
             rwall_roi(562,95,227,432);  

    cv::Mat res = img.clone();             // copy input image
    img(door_roi ).copyTo(res(rwall_roi)); // copy door ROI to right
    img(door_roi ).copyTo(res(lwall_roi)); // copy door ROI to left
    img(rwall_roi).copyTo(res(door_roi )); // copy wall over door
    cv::imshow("Simple Copy - a.k.a. Stamp Tool", res); cv::waitKey();

    cv::Mat mask(cv::Mat::zeros(img.size(), CV_8UC1)); // prepare door mask
    mask(door_roi).setTo(255);                         // white ROI on black background
    auto roiCenter = [](auto const& roi) { return roi.tl() + cv::Point(roi.width / 2, roi.height / 2); };
    cv::seamlessClone(img, img, mask, roiCenter(rwall_roi), res, cv::NORMAL_CLONE); // clone door ROI to right    
    cv::seamlessClone(img, res, mask, roiCenter(lwall_roi), res, cv::NORMAL_CLONE); // clone door ROI to left

    mask.setTo(0);                                                                  // prepare wall ROI
    mask(rwall_roi).setTo(255);                                                     // white ROI on black background
    cv::seamlessClone(img, res, mask, roiCenter(door_roi),  res, cv::NORMAL_CLONE); // clone wall over door
    cv::imshow("Seamless Cloning", res); cv::waitKey();
}