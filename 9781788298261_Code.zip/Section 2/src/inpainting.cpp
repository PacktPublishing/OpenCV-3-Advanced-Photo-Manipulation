#include <opencv2/opencv.hpp>
using namespace cv;
int main(int argc, char* argv[])
{   
    Mat img = imread(argv[1]);          // read image
    if (img.empty()) 
        return EXIT_FAILURE;
    imshow("Input", img); waitKey();    // and show it
       
    Mat mask, inpainted;
    auto inpaint_red = [&](cv::Mat& img, std::string postfix = "")
    {
        inRange(img, Scalar(0, 0, 250), Scalar(0, 0, 255), mask);   // create mask
        inpaint(img, mask, inpainted, 3, CV_INPAINT_TELEA);         // inpaint!
        imshow("Mask"      + postfix, mask     ); waitKey();        // show mask
        imshow("Inpainted" + postfix, inpainted); waitKey();        // show inpainted image
    };
    inpaint_red(img);   // inpaint input image

    // Let's add noise!
    randu(mask, 0, 256);                                // create noise mask
    threshold(mask, mask, 254,255, CV_THRESH_BINARY);   // make binary
    dilate(mask, mask, {});                             // dilate pixels
    img.setTo(Scalar(0, 0, 255), mask);                 // overwrite pixels!
    imshow("Input + Noise", img); waitKey();            
    inpaint_red(img, " + Noise");                       // inpaint again
}