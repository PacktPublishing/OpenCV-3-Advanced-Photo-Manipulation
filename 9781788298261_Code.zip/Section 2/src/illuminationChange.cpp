#include <opencv2/opencv.hpp>
using namespace cv;
int main(int argc, char* argv[])
{
    Mat fgImg = imread(argv[1]);                              // read forground image
    imshow("Input", fgImg); waitKey();                        // and show it
    cv::Mat res, mask(cv::Mat::zeros(fgImg.size(), CV_8UC1)); // create mask
    mask(Rect(309, 184, 443, 246)).setTo(255);  

    // iterate over all background images
    for (auto imgName : std::vector<char*>(argv + 2, argv + argc)) 
    {
        Mat bgImg = imread(imgName); // read BGR image
        if (bgImg.empty()) continue; // skip invalid args/images
        imshow("Background", bgImg); // and show it

        // clone forgound image onto background image and show result
        seamlessClone(fgImg, bgImg, mask, { 670,130 }, res, cv::MIXED_CLONE);
        imshow("Result", res); waitKey();
    }
}