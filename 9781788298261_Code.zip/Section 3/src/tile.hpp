#pragma once
#include <vector>
#include <opencv2/opencv.hpp>
cv::Mat tile(const std::vector<cv::Mat> &images)
{
    if (images.empty() || images[0].empty()) return {};
    cv::Mat dst(images[0].size(), images[0].type());
    int side = int(ceil(sqrt(images.size())));
    int w = dst.cols / side, h = dst.rows / side;
    for (int i = 0, k = 0; i < side; ++i)
        for (int j = 0; j < side && k < images.size(); ++j, ++k)
            resize(images[k], dst(cv::Rect(j*w, i*h, w, h)), { w, h });  // resize directly into dst
    return dst;
}