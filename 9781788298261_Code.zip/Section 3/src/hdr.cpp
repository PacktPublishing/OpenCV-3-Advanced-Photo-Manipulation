#include <opencv2/opencv.hpp>
#include "tile.hpp"
void loadPhotos(std::string const& configFile, std::vector<cv::Mat>&, std::vector<float>&);
int main(int, char*argv[])
{
    using namespace cv;
    std::vector<Mat> images;
    std::vector<float> times;
    loadPhotos(argv[1], images, times);                             // load photos and exposure data
    imshow("Exposures", tile(images)); waitKey();                   // create and show a contact-sheet of all photos
    Mat response, hdr, ldr;
    createCalibrateDebevec()->process(images, response, times);     // find camera response curve
    createMergeDebevec()->process(images, hdr, times, response);    // create 32-bit HDR image
    imshow("HDR", hdr); waitKey();
    createTonemapDrago(2.2f)->process(hdr, ldr);                     // tone map to 8-bit LDR
    imshow("LDR", 1.5*(ldr-.1)); waitKey();
    return 0;
}

void loadPhotos(std::string const& configFile, std::vector<cv::Mat>& images, std::vector<float>& times)
{
    std::ifstream photoList(configFile);
    std::string name;
    float val;
    while (photoList >> name >> val) 
        images.push_back(cv::imread(name)), times.push_back(1.f / val); // invert exposure value
}