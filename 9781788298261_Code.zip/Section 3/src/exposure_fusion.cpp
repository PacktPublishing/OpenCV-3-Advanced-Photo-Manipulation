#include <vector>
#include <opencv2/opencv.hpp>
cv::Mat tile(const std::vector<cv::Mat> &images); // helper function
using namespace cv;
int main(int argc, char*argv[])
{
    auto filenames = std::vector<char*>(argv + 1, argv + argc);         // get exposure photo file names 
    auto images    = std::vector<Mat>(filenames.size());                // create a vector of cv::Mats of the same size
    std::transform(filenames.begin(), filenames.end(), images.begin(),  // load all photos
                   [](auto fname) { return imread(fname); });
    imshow("Exposures", tile(images)); waitKey();                       // create and show a contact sheet of all photos
    createAlignMTB()->process(images, images);                          // align images
    Mat fused;
    createMergeMertens()->process(images, fused);                       // create exposure fusion algorithm and Fuse!
    imshow("Exposure Fusion", fused); waitKey();                        // show fused result
}

Mat tile(const std::vector<Mat> &images)
{
    if (images.empty() || images[0].empty()) return {};             // make sure we have at least 1 valid image
    Mat dst(images[0].size(), images[0].type());                    // allocate tiled image - same size as 1st image
    int side = int(ceil(sqrt(images.size())));                      // side images per row
    int w = dst.cols / side, h = dst.rows / side;                   // thumbnail size is: w x h
    for (int i = 0, k = 0; i < side; ++i)
        for (int j = 0; j < side && k < images.size(); ++j, ++k)
            resize(images[k], dst(Rect(j*w, i*h, w, h)), { w, h }); // resize directly into dst
    return dst;                                                     // return tile image
}