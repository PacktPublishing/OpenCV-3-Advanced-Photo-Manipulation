#include <vector>
#include <opencv2/opencv.hpp>
using namespace cv;
int main(int argc, char* argv[])
{   
    // iterate over all input images
    for (auto imgName : std::vector<char*>(argv + 1, argv + argc))
    {   
        Mat img = imread(imgName);          // read BGR image
        if (img.empty()) continue;          // skip invalid args/images
        imshow("Color", img);               // and show it
        Mat chans[3], all;                  
        split(img, chans);                  // (1) split BGR channels
        hconcat(chans, 3, all);             //     tile them horizontally
        imshow("B :: G :: R", all);         //     and show them
        waitKey();
        Mat gray, luv, lightness, decolored, unused, hsv, desaturated3C;
        cvtColor(img, gray, CV_BGR2GRAY);   // (2) convert 'img' to grayscale
        cvtColor(img, luv,  CV_BGR2Luv);    // (3) convert 'img' to Luv colorspace
        extractChannel(luv, lightness, 0);  //     take L channel of Luv image
        decolor(img, decolored, unused);    // (4) apply decolor algorithm to 'img'
        hconcat(std::vector<Mat>({ gray, lightness, decolored }), all);
        imshow("Grayscale   ::   Luv Lightness   ::   Decolored", all);
        cvtColor(img, hsv, CV_BGR2HSV);     // (5) convert 'img' to HSV
        cvtColor(hsv & Vec3b(255,0,255),    //     zero-out Saturation channel
                 desaturated3C, CV_HSV2BGR);//     convert back to BGR
        imshow("Desaturated BGR", desaturated3C);
        waitKey();                          
        destroyAllWindows();                // close all windows
    }
}