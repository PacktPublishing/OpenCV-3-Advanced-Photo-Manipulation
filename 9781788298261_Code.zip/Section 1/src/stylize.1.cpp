#include <opencv2/opencv.hpp>
using namespace cv;
int main(int argc, char* argv[])
{   
    for (auto imgName : std::vector<char*>(argv + 1, argv + argc)) // iterate over all input images
    {   
        Mat img = imread(imgName);               // read BGR image
        if (img.empty()) continue;               // skip invalid args/images
        imshow("Input", img);                    // and show it

        // apply pencilSketch() and show results
        Mat pencil, gray_pencil;
        pencilSketch(img, gray_pencil, pencil);  
        imshow("Gray", gray_pencil);             
        imshow("Color", pencil);                 

        // apply stylization() and show result
        Mat stylized;                            
        stylization(img, stylized);              
        imshow("Stylized", stylized);            

        // apply edgePreservingFilter() and show result
        Mat filtered;               
        edgePreservingFilter(img, filtered, RECURS_FILTER);
        imshow("Edge Preserving Filter", filtered);

        waitKey();
    }
}