#include <opencv2/opencv.hpp>
int main(int argc, char* argv[])
{    
    for (auto imgName : std::vector<char*>(argv + 1, argv + argc)) 
    {   
        cv::Mat img = cv::imread(imgName);          // read BGR image
        if (img.empty()) continue;                  // skip invalid args/images
        cv::imshow("Window", img);                  // and show it

        cv::Mat enhanced;
        cv::detailEnhance(img, enhanced, 150,.5);   // Enhance details
        cv::Mat bc_fixed = (img - 78)*2.55;         // Brightness contrast corrected

        for (int key = 0; 27 != key; key = cv::waitKey()) // ESC breaks 
        {            
            switch (key)
            {
            case 'e': cv::imshow("Window", enhanced); break;
            case 'b': cv::imshow("Window", bc_fixed); break;
            default : cv::imshow("Window", img);
            }
        }
    }
}